#include <stdio.h>

int search(int a[], int n, int x) {
    for(int i = 0; i < n; i++) {
        if(a[i] == x)
            return i;
    }
    return -1;
}

int main() {
    int n, a[100], x;
    scanf("%d", &n);

    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);

    printf("Nhap gia tri can tim: ");
    scanf("%d", &x);

    int kq = search(a, n, x);
    printf("Index = %d", kq);

    return 0;
}
