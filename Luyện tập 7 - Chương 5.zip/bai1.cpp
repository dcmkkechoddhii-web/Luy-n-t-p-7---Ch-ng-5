#include <stdio.h>

int main() {
    int n, a[100], sum = 0;
    printf("Nhap n: ");
    scanf("%d", &n);

    for(int i = 0; i < n; i++) {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
        sum += a[i];
    }

    printf("Tong = %d", sum);
    return 0;
}
